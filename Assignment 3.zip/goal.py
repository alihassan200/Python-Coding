"""CSC148 Assignment 2

CSC148 Winter 2024
Department of Computer Science,
University of Toronto

This code is provided solely for the personal and private use of
students taking the CSC148 course at the University of Toronto.
Copying for purposes other than this use is expressly prohibited.
All forms of distribution of this code, whether as given or with
any changes, are expressly prohibited.

Authors: Diane Horton, David Liu, Mario Badr, Sophia Huynh, Misha Schwartz,
Jaisie Sin, and Joonho Kim

All of the files in this directory and all subdirectories are:
Copyright (c) Diane Horton, David Liu, Mario Badr, Sophia Huynh,
Misha Schwartz, Jaisie Sin, and Joonho Kim

Module Description:

This file contains the hierarchy of Goal classes and related helper functions.
"""
from __future__ import annotations
import random
from block import Block
from settings import colour_name, COLOUR_LIST


def generate_goals(num_goals: int) -> list[Goal]:
    """Return a randomly generated list of goals with length <num_goals>.

    Each goal must be randomly selectly from the two types of Goals provided and
    must have a different randomly generated colour from COLOUR_LIST.
    No two goals can have the same colour.

    Preconditions:
    - num_goals <= len(COLOUR_LIST)
 so in this code, i need to
 create a list with generate_goals that is must have the same type of goal
    """
    copy_colour = COLOUR_LIST.copy()
    goals = []
    for _i in range(num_goals):
        colour = random.choice(copy_colour)
        goals.append(random.choice([PerimeterGoal(colour), BlobGoal(colour)]))
        copy_colour.remove(colour)
    return goals


def flatten(block: Block) -> list[list[tuple[int, int, int]]]:
    """Return a two-dimensional list representing <block> as rows and columns of
    unit cells.

    Return a list of lists L, where,
    for 0 <= i, j < 2^{max_depth - self.level}
        - L[i] represents column i and
        - L[i][j] represents the unit cell at column i and row j.

    Each unit cell is represented by a tuple of 3 ints, which is the colour
    of the block at the cell location[i][j].

    L[0][0] represents the unit cell in the upper left corner of the Block.
    """
    size = 2 ** (block.max_depth - block.level)
    result = [[(0, 0, 0) for _ in range(size)] for _ in range(size)]

    if block.children:
        for child in block.children:
            child_row = child.position[0] - block.position[0]
            child_col = child.position[1] - block.position[1]
            row_offsets = child_row * size // block.size
            col_offsets = child_col * size // block.size
            childs_grid = flatten(child)
            for row in range(len(childs_grid)):
                for col in range(len(childs_grid[0])):
                    if row + row_offsets < size and col + col_offsets < size:
                        result[row + row_offsets][col + col_offsets] = (
                            childs_grid)[row][col]
    else:
       # if leaf turns out
        color = block.colour
        for i in range(size):
            for j in range(size):
                result[i][j] = color
    return result

    # if block.level == block.max_depth:  # Base case: Leaf block
    #     cell_colour = block.colour if block.colour else (0, 0, 0)
    #     return [[cell_colour]]
#
# flattened_children = [
#     flatten(child) for child in block.children if child.colour != (0, 0, 0)
# ]
#
# if not flattened_children:
#     return []

# Determine the maximum length of columns
# max_length = max(len(child) for child in flattened_children)
#
# # Create columns and then transpose them into rows
# columns = [flattened_child + [(0, 0, 0)] * (max_length - len(flattened_child))
#            for flattened_child in flattened_children]
#
# # Transpose the columns into rows
# rows = list(zip(*columns))
#
# return rows


class Goal:
    """A player goal in the game of Blocky.

    This is an abstract class. Only child classes should be instantiated.

    Instance Attributes:
    - colour: The target colour for this goal, that is the colour to which
              this goal applies.
    """
    colour: tuple[int, int, int]

    def __init__(self, target_colour: tuple[int, int, int]) -> None:
        """Initialize this goal to have the given <target_colour>.
        """
        self.colour = target_colour

    def score(self, board: Block) -> int:
        """Return the current score for this goal on the given <board>.

        The score is always greater than or equal to 0.
        """
        raise NotImplementedError

    def description(self) -> str:
        """Return a description of this goal.
        """
        raise NotImplementedError


class PerimeterGoal(Goal):
    """A goal to maximize the presence of this goal's target colour
    on the board's perimeter.
    """

    def score(self, board: Block) -> int:
        """Return the current score for this goal on the given board.

        The score is always greater than or equal to 0.

        The score for a PerimeterGoal is defined to be the number of unit cells
        on the perimeter whose colour is this goal's target colour. Corner cells
        count twice toward the score.
        """
        # Flatten the board to get a two-dimensional grid representation
        # perimeter_grid = flatten(board)
        #
        # perimeter_score = 0
        #
        # for i in range(len(perimeter_grid)):
        #     for j in range(len(perimeter_grid[i])):
        #         if self._is_perimeter_cell(i, j, len(perimeter_grid)):
        #             if perimeter_grid[i][j] == self.colour:
        # Use target colour attribute from Goal class
        #                 perimeter_score += 2
        #                 if self._is_corner_cell(i, j, len(perimeter_grid))
        #                 else 1
        #
        # return perimeter_score

        score = 0
        flattened = flatten(board)
        sizes = len(flattened)
        if sizes == 1:
            if self.colour == flattened[0][0]:
                return 4
            else:
                return 0
        else:
            # Check perimeter cells
            for i in range(sizes):
                for j in range(sizes):
                    if i == 0 or i == sizes - 1 or j == 0 or j == \
                            sizes - 1:
                        if flattened[i][j] == self.colour:
                            if (i in {0, sizes - 1}) and \
                                    (j in {0, sizes - 1}):
                                score += 2
                            else:
                                score += 1
        return score

    def description(self) -> str:
        """Return a description of this goal.
        """

        return f'{colour_name(self.colour)} colour on the perimeter as possible'


class BlobGoal(Goal):
    """A goal to create the largest connected blob of this goal's target
    colour, anywhere within the Block.
    """

    def score(self, board: Block) -> int:
        """Return the current score for this goal on the given board.

        The score is always greater than or equal to 0.

        The score for a BlobGoal is defined to be the total number of
        unit cells in the largest connected blob within this Block.
        """

        lst = flatten(board)
        largest_blob = 0
        visited = []
        for _i in range(len(lst)):
            inner_lst = [-1] * len(lst)
            visited.append(inner_lst)

        for i in range(len(lst)):
            for j in range(len(lst[i])):
                blob = self._undiscovered_blob_size((i, j), lst, visited)
                largest_blob = max(largest_blob, blob)

        return largest_blob

    def _undiscovered_blob_size(self, pos: tuple[int, int],
                                board: list[list[tuple[int, int, int]]],
                                visited: list[list[int]]) -> int:
        """Return the size of the largest connected blob in <board> that (a) is
        of this Goal's target <colour>, (b) includes the cell at <pos>, and (c)
        involves only cells that are not in <visited>.

        <board> is the flattened board on which to search for the blob.
        <visited> is a parallel structure (to <board>) that, in each cell,
        contains:
            -1 if this cell has never been visited
            0  if this cell has been visited and discovered
               not to be of the target colour
            1  if this cell has been visited and discovered
               to be of the target colour

        Update <visited> so that all cells that are visited are marked with
        either 0 or 1.

        If <pos> is out of bounds for <board>, return 0.
        """
        a, b = pos
        if a < 0 or a >= len(board) or b < 0 or b >= len(board[0]):
            return 0

        if visited[pos[0]][pos[1]] != -1:
            return 0

        if board[pos[0]][pos[1]] != self.colour:
            visited[pos[0]][pos[1]] = 0
            return 0

        visited[pos[0]][pos[1]] = 1
        count = 1
        neighbors = [(pos[0] - 1, pos[1]), (pos[0], pos[1] - 1),
                     (pos[0] + 1, pos[1]), (pos[0], pos[1] + 1)]
        for neighbor_pos in neighbors:
            count += self._undiscovered_blob_size(neighbor_pos, board, visited)
        return count

    def description(self) -> str:
        """Return a description of this goal.
        """
        return (f'player x is to create a largest blob for the '
                f'{colour_name(self.colour)}')


if __name__ == '__main__':
    import python_ta

    python_ta.check_all(config={
        'allowed-import-modules': [
            'doctest', 'python_ta', 'random', 'typing', 'block', 'settings',
            'math', '__future__'
        ],
        'max-attributes': 15
    })
