"""Assignment 1 - Tests for class PriorityQueue  (Task 3a)

This code is provided solely for the personal and private use of
students taking the CSC148 course at the University of Toronto.
Copying for purposes other than this use is expressly prohibited.
All forms of distribution of this code, whether as given or with
any changes, are expressly prohibited.

All of the files in this directory are
Copyright (c) Jonathan Calver, Diane Horton, Sophia Huynh, Joonho Kim and
Jacqueline Smith.

Module Description:
This module will contain tests for class PriorityQueue.
"""
from container import PriorityQueue


def test_empty() -> None:
    """Test if it is empty """
    s = PriorityQueue()
    s.add('ali')
    assert s.is_empty() == False
    s.remove()
    assert s.is_empty() == True

def test_is_empty_one() -> None:
    """Test if if the queue is not empty"""

    s = PriorityQueue()
    assert s.is_empty() == True


def test_is_empty_two() -> None:
    s = PriorityQueue()
    s.add('ali')
    s.add('zain')
    assert s.is_empty() == False
    s.remove()
    assert s.is_empty() == False

def test_remove() -> None:
    """Test the remove function"""
    s = PriorityQueue()
    s.add(1)
    s.add(1)
    s.add(2)
    s.add(3)
    s.add(2)
    assert s.remove() == 1
    assert s.remove() == 1
    assert s.remove() == 2
    assert s.remove() == 2
    assert s.remove() == 3

def test_remove_one() -> None:
    """ Test the remove function"""
    s = PriorityQueue()
    s.add(1)
    s.add(2)
    s.add(1)
    s.add(1000)
    s.add(1)
    s.add(2)
    assert s.remove() == 1
    assert s.remove() == 1
    assert s.remove() == 1
    assert s.remove() == 2
    assert s.remove() == 2
    assert s.remove() == 1000


def test_remove_two() -> None:
    new_add = 2
    id_1 = id(new_add)
    s = PriorityQueue()
    s._items = [1, 2, 2, 99, 100]
    s.add(new_add)
    assert s._items == [1, 2, 2, 2, 99, 100] and id_1 == id(s._items[3])


def test_add() -> None:
    """Test the add function"""
    s = PriorityQueue()
    s.add('anna')
    s.add('fred')
    s.add('zain')
    s.add('fred')
    assert s._items == ['anna', 'fred', 'fred', 'zain']

def test_add_one() -> None:
    """Test the added function"""
    s = PriorityQueue()
    s.add('anna')
    s.add('fred')
    s.add('zain')
    s.add('fred')
    assert s._items == ['anna', 'fred', 'fred', 'zain']
    s.add('bilal')
    assert s._items == ['anna', 'bilal', 'fred', 'fred', 'zain']

def test_add_when_empty() -> None:
    """Test when lis is empty"""
    s1 = PriorityQueue()
    s1.add(4)
    assert s1._items == [4]

if __name__ == '__main__':
    import pytest
    pytest.main(['test_priority_queue.py'])
