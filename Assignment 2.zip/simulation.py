"""Assignment 1 - Grocery Store Simulation (Task 4)

CSC148 Winter 2024
Department of Computer Science,
University of Toronto

This code is provided solely for the personal and private use of
students taking the CSC148 course at the University of Toronto.
Copying for purposes other than this use is expressly prohibited.
All forms of distribution of this code, whether as given or with
any changes, are expressly prohibited.

All of the files in this directory are
Copyright (c) Jonathan Calver, Diane Horton, Sophia Huynh, Joonho Kim and
Jacqueline Smith.

Module Description:

This file drives a simulation of customers checking out at a grocery store.
"""
from __future__ import annotations

from typing import TextIO
from event import (Event, create_event_list, CustomerArrival,
                   CheckoutCompleted, CloseLine, CheckoutStarted)
from store import GroceryStore
from container import PriorityQueue


class GroceryStoreSimulation:
    """A Grocery Store simulation.

    Attributes:
    - _events: A sequence of events arranged in priority order determined by
            the event comparison methods. For any two events e1 and e2,
            if e1 < e2 then e1 will come out of the event queue before e2.
            If e1 == e2 (according to the event comparison defined by __eq__),
            then the event that was inserted *earlier* is the first one to be
            removed.
    - _store: The store being simulated.
    - stats: Summary statistics for the simulation, with these keys and values:
            'num_customers': the total number of customers in the simulation
            'total_time': the timestamp of the last event
            'max_wait': the maximum amount of time a customer waited
      All statistics begin at 0 and are updated as each event is handled.
    - customer_name: list of customer name
    - all_events: list of all events

    Representation Invariants:
    - For every event in self._events that involves a checkout line number n,
      0 <= n <= self._store.num_lines.
    """
    _events: PriorityQueue
    _store: GroceryStore
    stats: dict[str, int]
    customer_names: list
    all_events: list

    def __init__(self, store_file: TextIO) -> None:
        """Initialize a GroceryStoreSimulation using the store information in
        <store_file>.

        All statistics begin at 0.

        Preconditions:
        - store_file is a valid JSON configuration file with the keys
          regular_count, express_count, self_serve_count, and line_capacity
        - store_file is open
        - All values in store_file are >= 0
        """
        self._events = PriorityQueue()
        self._store = GroceryStore(store_file)
        self.stats = {'num_customers': 0, 'total_time': 0, 'max_wait': 0}
        self.customer_names = []

    def run(self, initial_events: list[Event]) -> None:
        """Run the simulation on the events stored in <initial_events>.

        Reset the statistics for the simulation before the simulation is run.

        Precondition:
        - For every event in initial_events that involves a checkout line
          number n, 0 <= n <= self._store.num_lines.
        - initial_events does not include two CustomerArrival events a1 and a2
          such that a1.customer.name == a2.customer.name # the name arent equal
        - The events in initial_events are such that the simulation will
          eventually end. For example, the checkout lines will not all be
          made to close when there are remaining customers.
        """
        self.customer_names = []
        self.stats = {'num_customers': 0, 'total_time': 0, 'max_wait': 0}
        self.all_events = []

        for event in initial_events:
            self._events.add(event)
            self.all_events.append(event)

        while not self._events.is_empty():
            x = self._events.remove()

        # Process each type of event
            if isinstance(x, CustomerArrival):
                self.process_customer_arrival(x)
            elif isinstance(x, CheckoutStarted):
                self.process_checkout_started(x)
            elif isinstance(x, CheckoutCompleted):
                self.process_checkout_completed(x)
            elif isinstance(x, CloseLine):
                self.process_close_line(x)

    def calculate_max_wait_time(self, completed_event: CheckoutCompleted,
                                initial_events: list[Event]) -> int:
        """Calculate the maximum wait time for a customer."""
        max_wait_time = 0
        for event in initial_events:
            if (isinstance(event, CustomerArrival) and event.customer.name
                    == completed_event.customer.name
                    and event.timestamp < completed_event.timestamp):

                wait_time = completed_event.timestamp - event.timestamp
                max_wait_time = max(max_wait_time, wait_time)
        return max_wait_time

    def process_customer_arrival(self, event: CustomerArrival) -> None:
        """Process a CustomerArrival event."""
        for new_event in event.do(self._store):
            self._events.add(new_event)
        if event.customer.name not in self.customer_names:
            self.customer_names.append(event.customer.name)
            self.stats['num_customers'] += 1

    def process_checkout_started(self, event: CheckoutStarted) -> None:
        """Process a CheckoutStarted event."""
        for new_event in event.do(self._store):
            self._events.add(new_event)

    def process_checkout_completed(self, event: CheckoutCompleted) -> None:
        """Process a CheckoutCompleted event."""

        max_wait_time_1 = self.calculate_max_wait_time(event, self.all_events)
        self.stats['max_wait'] = max(max_wait_time_1, self.stats['max_wait'])
        self.stats['total_time'] = event.timestamp
        for new_event in event.do(self._store):
            self._events.add(new_event)
            self.all_events.append(new_event)

    def process_close_line(self, event: CloseLine) -> None:
        """Process a CloseLine event."""
        for new_event in event.do(self._store):
            self._events.add(new_event)


if __name__ == '__main__':
    config_file_name = 'input_files/config_111_01.json'
    with open(config_file_name) as config_file:
        sim = GroceryStoreSimulation(config_file)
        config_file.close()

    # By using "with ... as ...", we get Python to automatically close the
    # file for us at the end of the "with" clause.
    event_file_name = 'input_files/events_no_express.txt'
    with open(event_file_name) as event_file:
        events = create_event_list(event_file)
    sim.run(events)
    print(sim.stats)
    import doctest
    doctest.testmod()

    check_pyta = True
    if check_pyta:
        import python_ta
        python_ta.check_all(config={
            'allowed-import-modules': ['__future__', 'typing', 'event', 'store',
                                       'container', 'python_ta', 'doctest']})
